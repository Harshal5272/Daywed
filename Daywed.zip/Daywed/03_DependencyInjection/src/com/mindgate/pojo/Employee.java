package com.mindgate.pojo;

public class Employee {

	private int employeeid;
	private String name;
	private double salary;
	private Address homeaddress;

	public Employee() {
		System.out.println("default constructor of Employee called");
		// TODO Auto-generated constructor stub
	}

	public Employee(int employeeid, String name, double salary, Address homeaddress) {
		super();
		this.employeeid = employeeid;
		this.name = name;
		this.salary = salary;
		this.homeaddress = homeaddress;
		System.out.println("overloaded constructor of Employee called");
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		System.out.println("setting ::"+ employeeid);
		this.employeeid = employeeid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("setting ::"+ name);
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		System.out.println("setting ::"+ salary);
		this.salary = salary;
	}

	public Address getHomeaddress() {
		return homeaddress;
	}

	public void setHomeaddress(Address homeaddress) {
		this.homeaddress = homeaddress;
	}

	@Override
	public String toString() {
		return "Employee [employeeid=" + employeeid + ", name=" + name + ", salary=" + salary + ", homeaddress="
				+ homeaddress + "]";
	}

}
