package com.mindgate.pojo;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("address")
@Scope("prototype")

public class Address {
	private int address;
	private String street;
	private String city;
	private String state;

	public Address() {
		System.out.println("default constructor of Address called ");

	}

	public Address(int address, String street, String city, String state) {
		super();
		this.address = address;
		this.street = street;
		this.city = city;
		this.state = state;
		System.out.println("overloaded constructor OF Address called");
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		System.out.println("setting address::" + address);
		this.address = address;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		System.out.println("setting street::" + street);
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		System.out.println("setting state::" + state);
		this.state = state;
	}

	@Override
	public String toString() {
		return "Address [address=" + address + ", street=" + street + ", city=" + city + ", state=" + state + "]";
	}

}
