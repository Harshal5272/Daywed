package com.mindgate.main;

import com.mindgate.pojo.Address;
import com.mindgate.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		Address address = new Address(10, "LINKROAD", "kalyan","maharashtra" );
		Employee employee = new Employee(20, "Hrahal", 251, address);

	}

}
